-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 11. Apr 2020 um 18:44
-- Server-Version: 10.4.11-MariaDB
-- PHP-Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr13_david_jaroska_bigevents`
--
CREATE DATABASE IF NOT EXISTS `cr13_david_jaroska_bigevents` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cr13_david_jaroska_bigevents`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `description` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `website` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `startingdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `event`
--

INSERT INTO `event` (`id`, `description`, `email`, `img`, `phone`, `capacity`, `website`, `category`, `address`, `title`, `startingdate`) VALUES
(5, 'In October of 1923, a young man from Vienna made his way to the United States – just a few years later, he created “Lovell Health House,” an icon of California Modernism. It made him one of the most famous architects of his time.', 'office@wienmuseum.at', 'https://events.wien.info/media/full/RichardNeutra.jpg', '0043 1 4000 8400', 50, 'www.wienmuseum.at', 'Entertainment', 'Felderstraße 6-8 1010 Wien', 'Richard Neutra', '2020-04-14 18:00:00'),
(6, 'The ALBERTINA Museum is devoting its spring exhibition of 2020 to one of the most important private collections of French modernist art.', 'info@albertina.at', 'https://events.wien.info/media/full/vincent_van_gogh_la_cafe_de_nuit_a_arles_1888_hahnloserjaegglistiftung_foto_reto_pedrini.jpg', '0043 1 534 83 0', 120, 'www.albertina.at', 'Museum', 'Albertinaplatz 1 1010 Wien', 'Van Gogh, Cézanne, Matisse, Hodler', '2020-04-14 10:00:00'),
(7, 'Starting on Easter Sunday, the Wiener Konzerthaus will start a new streaming series: In the newly created format \"Moments Musicaux from the Wiener Konzerthaus\", musicians will play in small formations (solo, duo, trio) on the stage of the empty Great Hall', 'ticket@konzerthaus.at', 'https://events.wien.info/media/full/Konzerthaus_Fassade_credit_Herbert_Schwingenschl%C3%B6gl_1.jpg', '0043 1 242 002', 400, 'https://www.konzerthaus.at/', 'Streaming', 'Lothringerstraße 20 1030 Wien', 'Konzertzuhaus', '2020-04-12 19:00:00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `migration_versions`
--

CREATE TABLE `migration_versions` (
  `version` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Daten für Tabelle `migration_versions`
--

INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
('20200411121901', '2020-04-11 12:19:39'),
('20200411122138', '2020-04-11 12:21:48'),
('20200411130508', '2020-04-11 13:05:12'),
('20200411131232', '2020-04-11 13:12:39'),
('20200411131616', '2020-04-11 13:16:21'),
('20200411131743', '2020-04-11 13:17:48'),
('20200411141128', '2020-04-11 14:11:32'),
('20200411141637', '2020-04-11 14:16:41'),
('20200411153512', '2020-04-11 15:35:19'),
('20200411153705', '2020-04-11 15:37:09'),
('20200411154037', '2020-04-11 15:40:42'),
('20200411163030', '2020-04-11 16:30:35');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `migration_versions`
--
ALTER TABLE `migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
