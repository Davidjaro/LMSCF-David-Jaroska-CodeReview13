<?php 
	namespace App\Controller;

	use Symfony\Component\HttpFoundation\Response;
	use Symfony\Component\HttpFoundation\Request;
	use Symfony\Component\Routing\Annotation\Route;
	use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
	use Symfony\Bundle\FrameworkBundle\Controller\Controller;
	use App\Entity\Event;
	use Symfony\Component\Form\Extension\Core\Type\TextType;
	use Symfony\Component\Form\Extension\Core\Type\TextareaType;
	use Symfony\Component\Form\Extension\Core\Type\SubmitType;
	use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
	use Symfony\Component\Form\Extension\Core\Type\NumberType;
	
	class EventController extends Controller{
		/**
		* @Route("/", name="event_list")
		* @Method({"GET"})
		*/
		public function index(){

			$events = $this->getDoctrine()->getRepository(Event::class)->findAll();
			// return new Response('<html><body>Hello</body></html>');
			return $this->render('events/index.html.twig', array ('events' => $events));
		}

		/**
		* @Route ("/event/new", name="new_event")
		* @Method ({"GET", "POST"})
		*/

		public function new(Request $request) {
			$event = new Event();

			$form = $this->createFormBuilder($event)
			->add('title', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('email', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('phone', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('capacity', NumberType::class, array('attr' => array ('class' => 'form-control')))
			->add('description', TextareaType::class, array('attr' => array ('class' => 'form-control')))
			->add('img', TextType::class, array('label' => 'Link to Image', 'attr' => array ('class' => 'form-control')))
			->add('startingdate', DateTimeType::class, array('attr' => array ('class' => 'form-control')))
			->add('website', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('address', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('category', TextType::class, array('attr' => array ('class' => 'form-control')))

			->add('save', SubmitType::class, array('label' => 'Create', 'attr' => array ('class' => 'btn btn-primary mt-3')))
			->getForm();

			$form->handleRequest($request);

			if ($form->isSubmitted() && $form->isValid()){
				$event = $form->getData();

				$entityManager = $this->getDoctrine()->getManager();
				$entityManager->persist($event);
				$entityManager->flush();

				return $this->redirectToRoute('event_list');
			}

			return $this->render('events/new.html.twig', array ('form' => $form->createView()));
		}

		/**
		* @Route ("/event/edit/{id}", name="edit_event")
		* @Method ({"GET", "POST"})
		*/

		public function edit(Request $request, $id) {
			$event = new Event();
			$event = $this->getDoctrine()->getRepository(Event::class)->find($id);

			$form = $this->createFormBuilder($event)
			->add('title', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('email', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('phone', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('capacity', NumberType::class, array('attr' => array ('class' => 'form-control')))
			->add('description', TextareaType::class, array('attr' => array ('class' => 'form-control')))
			->add('img', TextType::class, array('label' => 'Link to Image', 'attr' => array ('class' => 'form-control')))
			->add('startingdate', DateTimeType::class, array('attr' => array ('class' => 'form-control')))
			->add('website', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('address', TextType::class, array('attr' => array ('class' => 'form-control')))
			->add('category', TextType::class, array('attr' => array ('class' => 'form-control')))

			->add('save', SubmitType::class, array('label' => 'Update', 'attr' => array ('class' => 'btn btn-primary mt-3')))
			->getForm();

			$form->handleRequest($request);

			if ($form->isSubmitted() && $form->isValid()){

				$entityManager = $this->getDoctrine()->getManager();
				$entityManager->flush();

				return $this->redirectToRoute('event_list');
			}

			return $this->render('events/edit.html.twig', array ('form' => $form->createView()));
		}




		/**
		* @Route ("/event/{id}", name="single_event")
		*/

		public function show($id){
			$event = $this->getDoctrine()->getRepository(Event::class)->find($id);

			return $this->render('events/show.html.twig', array ('event' => $event));
		}

		/**
		* @Route ("/event/delete/{id}")
		* @Method ({"DELETE"})
		*/

		public function delete(Request $request, $id){
		$event = $this->getDoctrine()->getRepository(Event::class)->find($id);

		$entityManager = $this->getDoctrine()->getManager();
		$entityManager->remove($event);
		$entityManager->flush();

		$response = new Response();
		$response->send();

		}



		
	}