<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\EventRepository")
 */
class Event
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    public function getId(): ?int
    {
        return $this->id;
    }
    /** 
    * @ORM\Column(type="text", length=100)
    */
    private $title;

    /** 
    * @ORM\Column(type="text", length=255)
    */

    private $description;

    /**
    * @ORM\Column(type="datetime")
    */
    private $startingdate;

    /** 
    * @ORM\Column(type="text", length=100)
    */

    private $email;

    /** 
    * @ORM\Column(type="text", length=255)
    */

    private $img;

    /** 
    * @ORM\Column(type="text", length=100)
    */

    private $phone;

    /** 
    * @ORM\Column(type="integer")
    */

    private $capacity;

    /** 
    * @ORM\Column(type="text", length=255)
    */

    private $website;

    /** 
    * @ORM\Column(type="text")
    */

    private $category;

    /** 
    * @ORM\Column(type="text", length=255)
    */

    private $address;

    public function getTitle(){
        return $this->title;
    }
    public function setTitle($title){
        return $this->title = $title;
    }
    public function getStartingdate(){
        return $this->startingdate;
    }
    public function setStartingdate($startingdate){
        return $this->startingdate = $startingdate;
    }
    public function getDescription(){
        return $this->description;
    }
    public function setDescription($description){
        return $this->description = $description;
    }
    public function getEmail(){
        return $this->email;
    }
    public function setEmail($email){
        return $this->email = $email;
    }
    public function getImg(){
        return $this->img;
    }
    public function setImg($img){
        return $this->img = $img;
    }
    public function getPhone(){
        return $this->phone;
    }
    public function setPhone($phone){
        return $this->phone = $phone;
    }
    public function getCapacity(){
        return $this->capacity;
    }
    public function setCapacity($capacity){
        return $this->capacity = $capacity;
    }
    public function getWebsite(){
        return $this->website;
    }
    public function setWebsite($website){
        return $this->website = $website;
    }
    public function getCategory(){
        return $this->category;
    }
    public function setCategory($category){
        return $this->category = $category;
    }
    public function getAddress(){
        return $this->address;
    }
    public function setAddress($address){
        return $this->address = $address;
    }
}
